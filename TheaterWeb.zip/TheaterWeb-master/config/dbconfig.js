var oracledb = require('oracledb');

module.exports = {
		  user          : envConfig.dbConfig.user,
		  password      : envConfig.dbConfig.password,
		  connectString : envConfig.dbConfig.connectString
};


