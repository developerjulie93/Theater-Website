var oracledb = require('oracledb');


oracledb.createPool (
	{
		user : "JH",
		password : "kosaf46231",

	}	
	

);