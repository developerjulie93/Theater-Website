/**
 * New node file
 */

module.exports = function(paypal){
	  paypal.configure(envConfig.paypal.api);
};




